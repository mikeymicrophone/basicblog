var localizedStrings = new Object;

localizedStrings["Done"] = "Done";
